import { Calendar, MapPin, ArrowRight } from "lucide-react";
import { EVENTS } from "../data/navData";

export default function EventsSection() {
  return (
    <section id="events" data-testid="events-section" className="py-20 md:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="max-w-2xl">
          <div className="text-[11px] tracking-[0.3em] text-[#8B0F1A] font-semibold">
            UPCOMING EVENTS
          </div>
          <h2
            className="mt-3 font-serif text-4xl md:text-5xl text-neutral-900"
            style={{ fontFamily: "'Playfair Display', Georgia, serif" }}
          >
            Convenings that shape <span className="italic text-[#8B0F1A]">Indian industry.</span>
          </h2>
        </div>

        <div className="mt-12 grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {EVENTS.map((ev, i) => (
            <article
              key={ev.title}
              className={`group relative overflow-hidden rounded-2xl border border-neutral-200 bg-white hover:shadow-2xl transition-all duration-300 ${
                i === 0 ? "md:col-span-2 md:row-span-2" : ""
              }`}
            >
              <div className={`relative overflow-hidden ${i === 0 ? "h-80 md:h-full" : "h-48"}`}>
                <img
                  src={ev.img}
                  alt={ev.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                <div className="absolute top-4 left-4 px-2.5 py-1 rounded-full bg-[#E8A83A] text-[#1a1a1a] text-[10px] font-bold tracking-wide">
                  {ev.category.toUpperCase()}
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-5 text-white">
                  <div className="flex items-center gap-3 text-[11px] text-white/80 mb-2">
                    <span className="inline-flex items-center gap-1">
                      <Calendar className="h-3 w-3" /> {ev.date}
                    </span>
                    <span className="inline-flex items-center gap-1">
                      <MapPin className="h-3 w-3" /> {ev.location}
                    </span>
                  </div>
                  <h3
                    className={`font-serif leading-tight ${i === 0 ? "text-2xl md:text-3xl" : "text-lg"}`}
                    style={{ fontFamily: "'Playfair Display', Georgia, serif" }}
                  >
                    {ev.title}
                  </h3>
                  <button className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-[#F4C95D] opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition-all">
                    Register now <ArrowRight className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>

        <div className="mt-10 text-center">
          <a
            href="#events"
            data-testid="events-all-btn"
            className="inline-flex items-center gap-2 px-6 py-3 border-2 border-[#8B0F1A] text-[#8B0F1A] hover:bg-[#8B0F1A] hover:text-white text-sm font-semibold rounded-full transition-all"
          >
            View Full Events Calendar
            <ArrowRight className="h-4 w-4" />
          </a>
        </div>
      </div>
    </section>
  );
}
