import { Megaphone, Newspaper, ArrowUpRight } from "lucide-react";
import { PRESS_RELEASES, PRESS_COVERAGE } from "../data/navData";

export default function MediaSection() {
  return (
    <section
      id="media"
      data-testid="media-section"
      className="py-20 md:py-24 bg-[#FAF7F2] relative overflow-hidden"
    >
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage:
            "linear-gradient(#8B0F1A 1px, transparent 1px), linear-gradient(90deg, #8B0F1A 1px, transparent 1px)",
          backgroundSize: "60px 60px",
        }}
      />
      <div className="relative max-w-7xl mx-auto px-6">
        <div className="flex items-end justify-between flex-wrap gap-4">
          <div>
            <div className="text-[11px] tracking-[0.3em] text-[#8B0F1A] font-semibold">
              MEDIA ROOM
            </div>
            <h2
              className="mt-3 font-serif text-4xl md:text-5xl text-neutral-900"
              style={{ fontFamily: "'Playfair Display', Georgia, serif" }}
            >
              Press &amp; <span className="italic text-[#8B0F1A]">Public Voice</span>
            </h2>
          </div>
          <a
            href="#media"
            className="inline-flex items-center gap-1 text-sm font-semibold text-[#8B0F1A] hover:underline"
            data-testid="media-see-all"
          >
            View Gallery <ArrowUpRight className="h-4 w-4" />
          </a>
        </div>

        <div className="mt-12 grid lg:grid-cols-2 gap-10">
          {/* Press Releases */}
          <div data-testid="press-releases">
            <div className="flex items-center gap-2 mb-5">
              <Megaphone className="h-5 w-5 text-[#8B0F1A]" />
              <h3 className="font-serif text-2xl text-neutral-900">Press Releases</h3>
            </div>
            <div className="space-y-4">
              {PRESS_RELEASES.map((p, i) => (
                <article
                  key={p.title}
                  className="group relative pl-8 pb-4 border-l-2 border-[#E8A83A]/50 last:border-l-transparent"
                >
                  <span className="absolute -left-[7px] top-1.5 w-3 h-3 rounded-full bg-[#8B0F1A] ring-4 ring-[#FAF7F2] group-hover:bg-[#E8A83A] transition-colors" />
                  <div className="text-[11px] uppercase tracking-wider text-neutral-500">
                    {p.date} · <span className="text-[#8B0F1A]">#{String(i + 1).padStart(2, "0")}</span>
                  </div>
                  <h4 className="mt-1 font-medium text-neutral-900 group-hover:text-[#8B0F1A] transition-colors">
                    {p.title}
                  </h4>
                </article>
              ))}
            </div>
          </div>

          {/* Press Coverage */}
          <div data-testid="press-coverage">
            <div className="flex items-center gap-2 mb-5">
              <Newspaper className="h-5 w-5 text-[#8B0F1A]" />
              <h3 className="font-serif text-2xl text-neutral-900">Press Coverage</h3>
            </div>
            <div className="space-y-4">
              {PRESS_COVERAGE.map((p) => (
                <article
                  key={p.title}
                  className="bg-white border border-neutral-200 rounded-xl p-5 hover:border-[#8B0F1A] hover:shadow-md transition-all"
                >
                  <div className="flex items-center justify-between text-[11px] uppercase tracking-wider mb-2">
                    <span className="text-[#8B0F1A] font-bold">{p.source}</span>
                    <span className="text-neutral-500">{p.date}</span>
                  </div>
                  <h4 className="font-medium text-neutral-900 leading-snug">{p.title}</h4>
                </article>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
