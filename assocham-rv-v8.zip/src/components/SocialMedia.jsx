// import { Facebook, Twitter, Linkedin, Youtube, Instagram, Rss } from "lucide-react";

// const SOCIALS = [
//   { Icon: Linkedin, label: "LinkedIn", handle: "@assocham4india", followers: "325K", color: "#0A66C2" },
//   { Icon: Twitter, label: "X (Twitter)", handle: "@ASSOCHAM4India", followers: "512K", color: "#111827" },
//   { Icon: Facebook, label: "Facebook", handle: "ASSOCHAM", followers: "284K", color: "#1877F2" },
//   { Icon: Youtube, label: "YouTube", handle: "@ASSOCHAM", followers: "96K", color: "#FF0000" },
//   { Icon: Instagram, label: "Instagram", handle: "@assocham.india", followers: "78K", color: "#E1306C" },
//   { Icon: Rss, label: "RSS Feed", handle: "assocham.org/feed", followers: "Live", color: "#E8A83A" },
// ];

// export default function SocialMedia() {
//   return (
//     <section
//       data-testid="social-media-section"
//       className="py-20 md:py-24 bg-gradient-to-br from-[#1a0708] via-[#2a0c10] to-[#3a0f14] text-white relative overflow-hidden"
//     >
//       <div className="pointer-events-none absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full bg-[#8B0F1A]/30 blur-3xl" />
//       <div className="relative max-w-7xl mx-auto px-6">
//         <div className="text-center max-w-2xl mx-auto">
//           <div className="text-[11px] tracking-[0.3em] text-[#E8A83A] font-semibold">
//             CONNECT WITH US
//           </div>
//           <h2
//             className="mt-3 font-serif text-4xl md:text-5xl leading-tight"
//             style={{ fontFamily: "'Playfair Display', Georgia, serif" }}
//           >
//             Join the conversation on <span className="italic text-[#F4C95D]">Indian industry.</span>
//           </h2>
//           <p className="mt-4 text-white/70 text-[15px]">
//             Follow ASSOCHAM across platforms for live updates on policy, sectors and events.
//           </p>
//         </div>

//         <div className="mt-14 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
//           {SOCIALS.map((s) => (
//             <a
//               key={s.label}
//               href="#"
//               data-testid={`social-${s.label.toLowerCase().replace(/s+/g, "-")}`}
//               className="group relative bg-white/5 hover:bg-white/10 backdrop-blur-sm border border-white/10 rounded-2xl p-5 transition-all hover:-translate-y-1"
//             >
//               <div
//                 className="w-11 h-11 rounded-xl flex items-center justify-center mb-3 transition-colors"
//                 style={{ backgroundColor: `${s.color}22`, color: s.color }}
//               >
//                 <s.Icon className="h-5 w-5" />
//               </div>
//               <div className="text-sm font-semibold">{s.label}</div>
//               <div className="text-[11px] text-white/60 mt-0.5 truncate">{s.handle}</div>
//               <div className="mt-3 pt-3 border-t border-white/10 text-[11px] text-[#F4C95D]">
//                 {s.followers} followers
//               </div>
//             </a>
//           ))}
//         </div>
//       </div>
//     </section>
//   );
// }




// new new code 




import { useState } from "react";
import { Youtube } from "lucide-react";

const VIDEOS = [
  "7YJxHDBBfWg",
  "tGG56vaD0Gc",
  "Y7Rl-e_yJUk",
  "pl3r5yT6I-0",
  "Iwbt2yZaKSc",
  "hY7m5jjJ9mM",
];

export default function SocialMedia() {
  const [activeVideo, setActiveVideo] = useState(null);

  return (
    <section className="py-20 md:py-24 bg-gradient-to-br from-[#1a0708] via-[#2a0c10] to-[#3a0f14] text-white relative overflow-hidden">
      
      {/* GLOW BG */}
      <div className="pointer-events-none absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full bg-[#8B0F1A]/30 blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-6">

        {/* HEADER */}
        <div className="text-center max-w-2xl mx-auto">
          <div className="text-[11px] tracking-[0.3em] text-[#E8A83A] font-semibold">
            CONNECT WITH US
          </div>

          <h2 className="mt-3 font-serif text-4xl md:text-5xl leading-tight">
            Join the conversation on{" "}
            <span className="italic text-[#F4C95D]">
              Indian industry.
            </span>
          </h2>

          <p className="mt-4 text-white/70 text-[15px]">
            Watch insights, events and updates from ASSOCHAM.
          </p>
        </div>

        {/* GRID */}
        <div className="mt-14 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">

          {VIDEOS.map((id, i) => (
            <div
              key={i}
              className="group relative bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl overflow-hidden transition-all hover:-translate-y-1"
              
              onMouseEnter={() => setActiveVideo(i)}
              onMouseLeave={() => setActiveVideo(null)}
            >
              
              {/* ICON */}
              <div className="absolute top-3 left-3 z-10 w-9 h-9 rounded-lg flex items-center justify-center bg-red-600 text-white shadow">
                <Youtube size={18} />
              </div>

              {/* VIDEO */}
              <div className="w-full h-[160px]">

                {activeVideo === i ? (
                  <iframe
                    className="w-full h-full"
                    src={`https://www.youtube.com/embed/${id}?autoplay=1&mute=1&controls=0&loop=1&playlist=${id}`}
                    title="YouTube video"
                    allow="autoplay"
                  ></iframe>
                ) : (
                  <iframe
                    className="w-full h-full opacity-80"
                    src={`https://www.youtube.com/embed/${id}?controls=0`}
                    title="YouTube video"
                  ></iframe>
                )}

              </div>

            </div>
          ))}

        </div>
      </div>
    </section>
  );
}