
// import { useState } from "react";
// import { FileText, Mail, Download, ArrowRight, Calendar } from "lucide-react";
// import { KNOWLEDGE_REPORTS, NEWSLETTERS } from "../data/navData";

// export default function KnowledgeCenter() {
//   const [tab, setTab] = useState("reports");

//   return (
//     <section id="knowledge" data-testid="knowledge-center" className="py-20 md:py-24 bg-white">
//       <div className="max-w-7xl mx-auto px-6">
//         <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
//           <div>
//             <div className="text-[11px] tracking-[0.3em] text-[#8B0F1A] font-semibold">
//               KNOWLEDGE CENTER
//             </div>
//             <h2
//               className="mt-3 font-serif text-4xl md:text-5xl leading-tight text-neutral-900"
//               style={{ fontFamily: "'Playfair Display', Georgia, serif" }}
//             >
//               Research that moves <span className="italic text-[#8B0F1A]">the needle.</span>
//             </h2>
//             <p className="mt-3 text-neutral-600 max-w-xl text-[15px]">
//               Deep-dive reports, whitepapers and a weekly newsletter distilled from
//               India&apos;s most relevant industry conversations.
//             </p>
//           </div>

//           {/* Tab switcher */}
//           <div className="inline-flex p-1 bg-neutral-100 rounded-full self-start">
//             <button
//               data-testid="kc-tab-reports"
//               onClick={() => setTab("reports")}
//               className={`px-5 py-2 text-sm font-medium rounded-full transition-all ${
//                 tab === "reports" ? "bg-[#8B0F1A] text-white shadow" : "text-neutral-600"
//               }`}
//             >
//               <FileText className="inline h-4 w-4 mr-1.5 -mt-0.5" />
//               Reports
//             </button>
//             <button
//               data-testid="kc-tab-newsletter"
//               onClick={() => setTab("newsletter")}
//               className={`px-5 py-2 text-sm font-medium rounded-full transition-all ${
//                 tab === "newsletter" ? "bg-[#8B0F1A] text-white shadow" : "text-neutral-600"
//               }`}
//             >
//               <Mail className="inline h-4 w-4 mr-1.5 -mt-0.5" />
//               Newsletter
//             </button>
//           </div>
//         </div>

//         {tab === "reports" ? (
//           <div className="mt-10 grid md:grid-cols-2 lg:grid-cols-3 gap-6" data-testid="kc-reports-grid">
//             {KNOWLEDGE_REPORTS.map((r) => (
//               <article
//                 key={r.title}
//                 className="group border border-neutral-200 rounded-2xl overflow-hidden hover:shadow-xl hover:-translate-y-1 transition-all bg-white"
//               >
//                 <div className="relative h-48 overflow-hidden">
//                   <img
//                     src={r.img}
//                     alt={r.title}
//                     className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
//                   />
//                   <div className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-white/95 text-[10px] font-bold tracking-wide text-[#8B0F1A]">
//                     {r.category.toUpperCase()}
//                   </div>
//                 </div>
//                 <div className="p-5">
//                   <div className="flex items-center gap-2 text-[11px] text-neutral-500">
//                     <Calendar className="h-3.5 w-3.5" />
//                     {r.date}
//                   </div>
//                   <h3 className="mt-2 font-serif text-lg leading-snug text-neutral-900 group-hover:text-[#8B0F1A] transition-colors">
//                     {r.title}
//                   </h3>
//                   <button className="mt-4 inline-flex items-center gap-1.5 text-[13px] font-semibold text-[#8B0F1A]">
//                     <Download className="h-3.5 w-3.5" />
//                     Download Report
//                   </button>
//                 </div>
//               </article>
//             ))}
//           </div>
//         ) : (
//           <div className="mt-10 grid lg:grid-cols-3 gap-6" data-testid="kc-newsletter-grid">
//             <div className="lg:col-span-1 bg-gradient-to-br from-[#8B0F1A] to-[#6d0b14] text-white rounded-2xl p-8 relative overflow-hidden">
//               <div className="absolute -right-8 -bottom-8 w-48 h-48 rounded-full bg-[#E8A83A]/20 blur-2xl" />
//               <Mail className="h-8 w-8 text-[#F4C95D]" />
//               <h3 className="mt-4 font-serif text-2xl leading-tight">
//                 The ASSOCHAM Weekly
//               </h3>
//               <p className="mt-2 text-sm text-white/80">
//                 India&apos;s policy & industry round-up — delivered every Friday morning.
//               </p>
//               <form
//                 className="mt-6 flex flex-col gap-2"
//                 onSubmit={(e) => {
//                   e.preventDefault();
//                   alert("Thanks — you'll receive the next issue on Friday.");
//                 }}
//               >
//                 <input
//                   type="email"
//                   required
//                   placeholder="you@company.in"
//                   data-testid="newsletter-email"
//                   className="px-4 py-3 rounded-full bg-white/10 border border-white/20 placeholder:text-white/60 text-sm outline-none focus:bg-white/20"
//                 />
//                 <button
//                   type="submit"
//                   data-testid="newsletter-subscribe"
//                   className="px-4 py-3 rounded-full bg-[#E8A83A] text-[#1a1a1a] text-sm font-semibold hover:bg-[#F4C95D] transition-colors"
//                 >
//                   Subscribe free
//                 </button>
//               </form>
//             </div>
//             <div className="lg:col-span-2 divide-y divide-neutral-200 border border-neutral-200 rounded-2xl bg-white">
//               {NEWSLETTERS.map((n) => (
//                 <div
//                   key={n.title}
//                   className="p-5 flex items-center justify-between gap-4 hover:bg-[#FFF9EC] transition-colors"
//                 >
//                   <div className="flex items-start gap-4 min-w-0">
//                     <div className="shrink-0 w-12 h-12 rounded-lg bg-[#FFF1E6] border border-[#E8A83A]/40 flex items-center justify-center">
//                       <FileText className="h-5 w-5 text-[#8B0F1A]" />
//                     </div>
//                     <div className="min-w-0">
//                       <h4 className="font-medium text-neutral-900 truncate">{n.title}</h4>
//                       <div className="text-xs text-neutral-500 mt-1">
//                         {n.date} · {n.pages} pages
//                       </div>
//                     </div>
//                   </div>
//                   <button className="shrink-0 inline-flex items-center gap-1 text-[13px] font-semibold text-[#8B0F1A] hover:underline">
//                     Read <ArrowRight className="h-3.5 w-3.5" />
//                   </button>
//                 </div>
//               ))}
//             </div>
//           </div>
//         )}
//       </div>
//     </section>
//   );
// }



import { knowledgeReports, newsletters } from "../data/navData";

export default function KnowledgeCenter() {
  return (
    <div style={{ background: "#f9f9f9", padding: "40px 0" }}>
      <div className="container">
        {/* Section header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
          <div className="section-title">Knowledge Center</div>
          <span className="view-all">Explore Knowledge Center →</span>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "3fr 1fr", gap: 30 }}>
          <ReportsGrid />
          <NewsletterList />
        </div>
      </div>
    </div>
  );
}

/* ---- Knowledge Reports 2x2 grid ---- */
function ReportsGrid() {
  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
        <div style={{ fontSize: 15, fontWeight: 700, color: "#222" }}>Knowledge Reports</div>
        <span className="view-all">View All</span>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 14 }}>
        {knowledgeReports.map((r, i) => (
          <ReportCard key={i} report={r} />
        ))}
      </div>
    </div>
  );
}

function ReportCard({ report }) {
  return (
    <div
      className="card-hover"
      style={{ background: "#fff", border: "1px solid #e5e7eb", borderRadius: 4, overflow: "hidden" }}
    >
      {/* Thumbnail with overlay title */}
      <div style={{ position: "relative", overflow: "hidden" }}>
      {/* <div style={{ position: "relative", height: 300, background: report.color, overflow: "hidden" }}> */}
        <img
          src={report.img}
          alt=""
          style={{ width: "100%", height: "100%", objectFit: "cover", opacity: 1,  }}
          // style={{ width: "100%", height: "100%", objectFit: "cover", opacity: 0.7, mixBlendMode: "multiply" }}
        />
        <div
          style={{
            position: "absolute", inset: 0,
            display: "flex", alignItems: "center", justifyContent: "center",
            padding: 12, textAlign: "center",
          }}
        >
          {/* <div
            style={{
              color: "#fff", fontWeight: 800, fontSize: 13,
              lineHeight: 1.3, textShadow: "0 1px 3px rgba(0,0,0,0.5)",
              textTransform: "uppercase",
            }}
          >
            {report.title}
          </div> */}
        </div>
      </div>

      {/* Card body */}
      <div style={{ padding: "10px 12px" }}>
        <div style={{ fontSize: 12, fontWeight: 600, color: "#333", marginBottom: 4 }}>{report.title}</div>
        <div style={{ fontSize: 11, color: "#999", marginBottom: 8 }}>{report.date}</div>
        <div style={{ fontSize: 11, color: "#c0392b", fontWeight: 600, cursor: "pointer" }}>⬇ Download PDF</div>
      </div>
    </div>
  );
}

/* ---- Newsletter list ---- */
function NewsletterList() {
  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
        <div style={{ fontSize: 15, fontWeight: 700, color: "#222" }}>Newsletter</div>
        <span className="view-all">View All</span>
      </div>

      {newsletters.map((n, i) => (
        <div
          key={i}
          className="card-hover"
          style={{
            background: "#fff", border: "1px solid #e5e7eb", borderRadius: 4,
            padding: 14, marginBottom: 12, display: "flex", gap: 12, alignItems: "center",
          }}
        >
          <img
            src={n.img}
            alt=""
            style={{ width: 70, height: 55, objectFit: "cover", borderRadius: 3, flexShrink: 0 }}
          />
          <div>
            <div style={{ fontSize: 13, fontWeight: 700, color: "#222", marginBottom: 3 }}>{n.title}</div>
            <div style={{ fontSize: 11, color: "#888", marginBottom: 8 }}>{n.issue}</div>
            <span style={{ fontSize: 12, color: "#c0392b", fontWeight: 600, cursor: "pointer" }}>Read More →</span>
          </div>
        </div>
      ))}
    </div>
  );
}
