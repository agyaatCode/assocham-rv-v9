// PillarsBar.jsx
// Horizontal strip of 8 key pillars below the hero slider

import { pillars } from "../data/navData";

export default function PillarsBar() {
  return (
    <div
      style={{
        background: "#fff",
        borderBottom: "1px solid #e5e7eb",
      }}
    >
      <div className="container">
        <div
          style={{
            display: "flex",
            overflowX: "auto",
          }}
        >
          {pillars.map((p, i) => {
            const Icon = p.icon;

            return (
              <div
                key={i}
                className="card-hover"
                style={{
                  flex: "0 0 12.5%",
                  padding: "18px 8px",
                  textAlign: "center",
                  borderRight:
                    i < pillars.length - 1
                      ? "1px solid #f0f0f0"
                      : "none",
                  cursor: "pointer",
                  minWidth: "140px",
                }}
              >
                {/* Icon */}
                <div
                  style={{
                    fontSize: 26,
                    marginBottom: 8,
                    color: "#d62027",
                    display: "flex",
                    justifyContent: "center",
                  }}
                >
                  <Icon size={26} />
                </div>

                {/* Label */}
                <div
                  style={{
                    fontSize: "11.5px",
                    fontWeight: 600,
                    color: "#333",
                    lineHeight: 1.3,
                  }}
                >
                  {p.label}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}