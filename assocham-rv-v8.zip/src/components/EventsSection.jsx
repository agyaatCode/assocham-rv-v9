// import { Calendar, MapPin, ArrowRight } from "lucide-react";
// import { EVENTS } from "../data/navData";

// export default function EventsSection() {
//   return (
//     <section id="events" data-testid="events-section" className="py-20 md:py-24 bg-white">
//       <div className="max-w-7xl mx-auto px-6">
//         <div className="max-w-2xl">
//           <div className="text-[11px] tracking-[0.3em] text-[#8B0F1A] font-semibold">
//             UPCOMING EVENTS
//           </div>
//           <h2
//             className="mt-3 font-serif text-4xl md:text-5xl text-neutral-900"
//             style={{ fontFamily: "'Playfair Display', Georgia, serif" }}
//           >
//             Convenings that shape <span className="italic text-[#8B0F1A]">Indian industry.</span>
//           </h2>
//         </div>

//         <div className="mt-12 grid md:grid-cols-2 lg:grid-cols-4 gap-6">
//           {EVENTS.map((ev, i) => (
//             <article
//               key={ev.title}
//               className={`group relative overflow-hidden rounded-2xl border border-neutral-200 bg-white hover:shadow-2xl transition-all duration-300 ${
//                 i === 0 ? "md:col-span-2 md:row-span-2" : ""
//               }`}
//             >
//               <div className={`relative overflow-hidden ${i === 0 ? "h-80 md:h-full" : "h-48"}`}>
//                 <img
//                   src={ev.img}
//                   alt={ev.title}
//                   className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
//                 />
//                 <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
//                 <div className="absolute top-4 left-4 px-2.5 py-1 rounded-full bg-[#E8A83A] text-[#1a1a1a] text-[10px] font-bold tracking-wide">
//                   {ev.category.toUpperCase()}
//                 </div>
//                 <div className="absolute bottom-0 left-0 right-0 p-5 text-white">
//                   <div className="flex items-center gap-3 text-[11px] text-white/80 mb-2">
//                     <span className="inline-flex items-center gap-1">
//                       <Calendar className="h-3 w-3" /> {ev.date}
//                     </span>
//                     <span className="inline-flex items-center gap-1">
//                       <MapPin className="h-3 w-3" /> {ev.location}
//                     </span>
//                   </div>
//                   <h3
//                     className={`font-serif leading-tight ${i === 0 ? "text-2xl md:text-3xl" : "text-lg"}`}
//                     style={{ fontFamily: "'Playfair Display', Georgia, serif" }}
//                   >
//                     {ev.title}
//                   </h3>
//                   <button className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-[#F4C95D] opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition-all">
//                     Register now <ArrowRight className="h-3.5 w-3.5" />
//                   </button>
//                 </div>
//               </div>
//             </article>
//           ))}
//         </div>

//         <div className="mt-10 text-center">
//           <a
//             href="#events"
//             data-testid="events-all-btn"
//             className="inline-flex items-center gap-2 px-6 py-3 border-2 border-[#8B0F1A] text-[#8B0F1A] hover:bg-[#8B0F1A] hover:text-white text-sm font-semibold rounded-full transition-all"
//           >
//             View Full Events Calendar
//             <ArrowRight className="h-4 w-4" />
//           </a>
//         </div>
//       </div>
//     </section>
//   );
// }





// new new code 





import { useEffect, useState } from "react";
import { Calendar, MapPin } from "lucide-react";
import { EVENTS } from "../data/navData";

const FLAGSHIP_IMAGES = [
  "https://assocham.org/assets/images/1739943966_SMK_2.0_ASSOCHAM%20Web%20Banner_650%20X%20914%20pixels.jpg",
  "https://assocham.org/assets/images/1772536051_Untitled%20design.jpg",
  "https://assocham.org/assets/images/1770812319_IMG-20260211-WA0043.jpg",
];

const LATEST_UPDATES = [
  "ASSOCHAM hosts Global Trade Summit 2026",
  "MSME policy reforms discussion held",
  "Digital India driving innovation",
  "Energy roadmap unveiled",
  "Startup ecosystem boost announced",
  "GOVERNMENT MEASURES TO MITIGATE IMPACT OF WEST ASIA CONFLICT ON INDIA",
  "D&B ASSOCHAM Report",
  "Industry Standards Note on Regulation 30 of the LODR Regulations",
  "SEBI Circular - Industry Standards on RPTs",
  "ASSOCHAM Compendium 2024",
];

export default function EventsSection() {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setIndex((prev) => (prev + 1) % FLAGSHIP_IMAGES.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  // duplicate for infinite loop
  const loopEvents = [...EVENTS.slice(1, 4), ...EVENTS.slice(1, 4)];
  const loopUpdates = [...LATEST_UPDATES, ...LATEST_UPDATES];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-6">

        <div className="grid lg:grid-cols-3 gap-8">

          {/* FLAGSHIP */}
          <div>
            <h3 className="text-sm font-semibold text-[#8B0F1A] mb-3">
              FLAGSHIP
            </h3>

            <div className="relative rounded-xl overflow-hidden h-[26rem] bg-black/2">

              <div className="h-full flex items-center justify-center">
                <img
                  src={FLAGSHIP_IMAGES[index]}
                  alt=""
                  className="max-h-full max-w-full object-contain"
                />
              </div>

              <div className="absolute inset-0 " />

              {/* <div className="absolute bottom-0 p-4 text-white">
                <div className="text-xs flex gap-3 text-white/80">
                  <span className="flex items-center gap-1">
                    <Calendar size={12} /> 24 Aug
                  </span>
                  <span className="flex items-center gap-1">
                    <MapPin size={12} /> Delhi
                  </span>
                </div>

                <h4 className="text-lg font-medium mt-1">
                  Global Leadership Summit
                </h4>
              </div> */}
            </div>
          </div>

          {/* UPCOMING EVENTS (INFINITE LOOP) */}
          <div>
            <h3 className="text-sm font-semibold text-[#8B0F1A] mb-3">
              UPCOMING
            </h3>

            <div className="relative h-[26rem] overflow-hidden">
              <div className="scroll-loop space-y-4">
                {loopEvents.map((ev, i) => (
                  <div
                    key={i}
                    className="flex gap-3 border rounded-lg overflow-hidden bg-white"
                  >
                    <img
                      src={ev.img}
                      alt=""
                      className="w-20 h-20 object-cover"
                    />

                    <div className="p-2">
                      <h4 className="text-xs font-medium">{ev.title}</h4>

                      <div className="text-[10px] text-neutral-500 mt-1">
                        {ev.date} • {ev.location}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* LATEST UPDATES */}
          <div>
            <h3 className="text-sm font-semibold text-[#8B0F1A] mb-3">
              LATEST UPDATES
            </h3>

            <div className="relative h-[26rem] overflow-hidden border rounded-lg bg-[#FAF7F2]">
              <div className="scroll-loop space-y-3 p-4">

                {loopUpdates.map((item, i) => (
                  <a key={i} href="#" className="latest-item">
                    <span className="bullet">•</span>
                    <span className="text">{item}</span>
                  </a>
                ))}

              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}