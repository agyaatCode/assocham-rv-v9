// import { ArrowRight, Newspaper, User, Globe2 } from "lucide-react";
// import { TICKER_ITEMS } from "../data/navData";

// export default function Hero() {
//   // Duplicate the list so the marquee is seamless
//   const loop = [...TICKER_ITEMS, ...TICKER_ITEMS];

//   return (
//     <section
//       id="home"
//       data-testid="hero-section"
//       className="relative overflow-hidden bg-gradient-to-br from-[#FFF9EC] via-white to-[#FFF1E6]"
//     >
//       {/* decorative rays */}
//       <div className="pointer-events-none absolute -top-40 -right-40 w-[520px] h-[520px] rounded-full bg-[#E8A83A]/20 blur-3xl" />
//       <div className="pointer-events-none absolute -bottom-40 -left-40 w-[520px] h-[520px] rounded-full bg-[#8B0F1A]/10 blur-3xl" />
//       <div
//         className="absolute inset-0 opacity-[0.04]"
//         style={{
//           backgroundImage:
//             "radial-gradient(#8B0F1A 1px, transparent 1px)",
//           backgroundSize: "22px 22px",
//         }}
//       />

//       <div className="relative max-w-7xl mx-auto px-6 pt-14 pb-10 md:pt-20 md:pb-16 grid lg:grid-cols-12 gap-10 items-center">
//         {/* Left — headline */}
//         <div className="lg:col-span-7">
//           <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#8B0F1A]/10 text-[#8B0F1A] text-xs font-medium tracking-wide">
//             <span className="w-1.5 h-1.5 rounded-full bg-[#8B0F1A] animate-pulse" />
//             Since 1920 · 105 Years of Service to the Indian Industry
//           </div>

//           <h1
//             className="mt-5 font-serif text-[40px] md:text-[56px] lg:text-[64px] leading-[1.02] tracking-tight text-[#1a1a1a]"
//             style={{ fontFamily: "'Playfair Display', Georgia, serif" }}
//           >
//             The voice of <span className="text-[#8B0F1A] italic">Indian Industry</span>,
//             <br />
//             shaping policy that{" "}
//             <span className="relative inline-block">
//               <span className="relative z-10">drives Bharat forward.</span>
//               <span className="absolute left-0 bottom-1 h-3 w-full bg-[#E8A83A]/40 -z-0" />
//             </span>
//           </h1>

//           <p className="mt-6 max-w-xl text-[15px] md:text-base text-neutral-600 leading-relaxed">
//             ASSOCHAM represents the collective will of India&apos;s businesses —
//             connecting policymakers, enterprises and innovators across 60+ sectors
//             and every Indian state.
//           </p>

//           <div className="mt-8 flex flex-wrap gap-3">
//             <a
//               href="#knowledge"
//               data-testid="hero-explore-btn"
//               className="group inline-flex items-center gap-2 px-6 py-3 bg-[#8B0F1A] hover:bg-[#6d0b14] text-white text-sm font-semibold rounded-full transition-all"
//             >
//               Explore Knowledge Centre
//               <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
//             </a>
//             <a
//               href="#membership"
//               data-testid="hero-membership-btn"
//               className="inline-flex items-center gap-2 px-6 py-3 border border-[#8B0F1A] text-[#8B0F1A] hover:bg-[#8B0F1A] hover:text-white text-sm font-semibold rounded-full transition-all"
//             >
//               Become a Member
//             </a>
//           </div>

//           {/* stats strip */}
//           <div className="mt-10 grid grid-cols-3 gap-4 max-w-lg">
//             {[
//               { icon: User, n: "4.5 L+", l: "Members" },
//               { icon: Globe2, n: "60+", l: "Sectors" },
//               { icon: Newspaper, n: "1,200+", l: "Reports" },
//             ].map((s) => (
//               <div key={s.l} className="flex items-start gap-2">
//                 <s.icon className="h-5 w-5 text-[#E8A83A] mt-1" />
//                 <div>
//                   <div className="text-2xl font-bold text-neutral-900">{s.n}</div>
//                   <div className="text-xs text-neutral-500 tracking-wide uppercase">
//                     {s.l}
//                   </div>
//                 </div>
//               </div>
//             ))}
//           </div>
//         </div>

//         {/* Right — visual card */}
//         <div className="lg:col-span-5">
//           <div className="relative">
//             <div className="absolute -inset-3 bg-gradient-to-br from-[#E8A83A]/40 to-[#8B0F1A]/20 blur-2xl rounded-[2rem]" />
//             <div className="relative rounded-[2rem] overflow-hidden border border-white shadow-2xl">
//               <img
//                 src="https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=1200&q=80"
//                 alt="India Gate, Delhi"
//                 className="w-full h-[420px] object-cover"
//               />
//               <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
//               <div className="absolute bottom-5 left-5 right-5 text-white">
//                 <div className="text-[10px] tracking-[0.25em] text-[#F4C95D]">
//                   FLAGSHIP EVENT
//                 </div>
//                 <div className="mt-1 font-serif text-xl md:text-2xl leading-tight">
//                   105th ASSOCHAM AGM
//                 </div>
//                 <div className="text-xs text-white/80 mt-1">
//                   December 18, 2025 · New Delhi
//                 </div>
//               </div>
//               <div className="absolute top-5 right-5 px-3 py-1 rounded-full bg-white/90 text-[#8B0F1A] text-[11px] font-semibold backdrop-blur">
//                 Registrations Open
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>

//       {/* Ticker — inside hero flex */}
//       <div
//         className="relative border-y border-[#8B0F1A]/15 bg-white/70 backdrop-blur-sm"
//         data-testid="hero-ticker"
//       >
//         <div className="max-w-7xl mx-auto px-6 flex items-center h-12 gap-4">
//           <div className="shrink-0 flex items-center gap-2 pr-4 border-r border-neutral-200">
//             <span className="inline-flex h-2 w-2 rounded-full bg-[#8B0F1A] animate-ping" />
//             <span className="text-[11px] font-bold tracking-[0.2em] text-[#8B0F1A]">
//               LIVE UPDATES
//             </span>
//           </div>
//           <div className="overflow-hidden relative flex-1 group">
//             <div className="flex gap-10 animate-[marquee_50s_linear_infinite] group-hover:[animation-play-state:paused] whitespace-nowrap">
//               {loop.map((t, i) => (
//                 <a
//                   key={i}
//                   href="#knowledge"
//                   className="text-[13px] text-neutral-700 hover:text-[#8B0F1A] font-medium inline-flex items-center gap-2"
//                 >
//                   <span className="text-[#E8A83A]">◆</span>
//                   {t}
//                 </a>
//               ))}
//             </div>
//           </div>
//         </div>
//       </div>
//     </section>
//   );
// }




// new new code 



import { useState, useEffect, useRef } from "react";
import { ArrowRight, Newspaper, User, Globe2 } from "lucide-react";
import { TICKER_ITEMS } from "../data/navData";

export default function Hero() {
  // 1. Ticker Data
  const loop = [...TICKER_ITEMS, ...TICKER_ITEMS];

  // 2. Carousel Data
  const originalCards = [
    {
      img: "https://assocham.org/assets/images/slider-banners/1774934463_3.jpg",
      title: "SAHIT Awardees at ASSOCHAM event Viksit Bharat 2047: Women Leading India’s Growth Story",
      date: "December 18, 2025 · New Delhi",
    },
    {
      img: "https://assocham.org/assets/images/slider-banners/1773920723_1.jpg",
      title: "Knowledge Paper launch during Nutribharat 2026 by Mr. Chirag Paswan, Hon'ble Minister for Food Processing Industries, GoI and other Industry Leaders",
      date: "January 2026 · Mumbai",
    },
    {
      img: "https://assocham.org/assets/images/slider-banners/1771224632_4.jpg",
      title: "Mr. Nirmal K Minda, President, ASSOCHAM with Shri M. Nagaraju, IAS, Sec, Dept of Financial Services, Ministry of Finance at ASSOCHAM Post Budget Conference",
      date: "March 2026 · Bengaluru",
    },
  ];

  // Infinite loop ke liye 1st card ko last mein add kiya
  const cards = [...originalCards, originalCards[0]];

  const [currentIndex, setCurrentIndex] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(true);
  const [isPaused, setIsPaused] = useState(false);

  // Auto-play logic
  useEffect(() => {
    if (isPaused) return;

    const timer = setInterval(() => {
      handleNext();
    }, 5000);

    return () => clearInterval(timer);
  }, [isPaused, currentIndex]);

  const handleNext = () => {
    setIsTransitioning(true);
    setCurrentIndex((prev) => prev + 1);
  };

  // Jab animation khatam ho, check karo ki kya hum clone par hain
  const handleTransitionEnd = () => {
    if (currentIndex >= cards.length - 1) {
      // Bina transition ke wapas 0 index par jump karo
      setIsTransitioning(false);
      setCurrentIndex(0);
    }
  };

  return (
    <section
      id="home"
      className="relative overflow-hidden bg-gradient-to-br from-[#FFF9EC] via-white to-[#FFF1E6]"
    >
      {/* Decorative Background Elements */}
      <div className="pointer-events-none absolute -top-40 -right-40 w-[520px] h-[520px] rounded-full bg-[#E8A83A]/20 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-40 -left-40 w-[520px] h-[520px] rounded-full bg-[#8B0F1A]/10 blur-3xl" />
      <div
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage: "radial-gradient(#8B0F1A 1px, transparent 1px)",
          backgroundSize: "22px 22px",
        }}
      />

      <div className="relative max-w-7xl mx-auto px-6 pt-14 pb-10 md:pt-20 md:pb-16 grid lg:grid-cols-12 gap-10 items-center">
        
        {/* Left Column — Content */}
        <div className="lg:col-span-7">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#8B0F1A]/10 text-[#8B0F1A] text-xs font-medium tracking-wide">
            <span className="w-1.5 h-1.5 rounded-full bg-[#8B0F1A] animate-pulse" />
            Since 1920 · 105 Years of Service to the Indian Industry
          </div>

          <h1
            className="mt-5 font-serif text-[40px] md:text-[56px] lg:text-[64px] leading-[1.02] tracking-tight text-[#1a1a1a]"
            style={{ fontFamily: "'Playfair Display', Georgia, serif" }}
          >
            The voice of <span className="text-[#8B0F1A] italic">Indian Industry</span>,
            <br />
            shaping policy that{" "}
            <span className="relative inline-block">
              <span className="relative z-10">drives Bharat forward.</span>
              <span className="absolute left-0 bottom-1 h-3 w-full bg-[#E8A83A]/40 -z-0" />
            </span>
          </h1>

          <p className="mt-6 max-w-xl text-[15px] md:text-base text-neutral-600 leading-relaxed">
            ASSOCHAM represents the collective will of India&apos;s businesses —
            connecting policymakers, enterprises and innovators across 60+ sectors
            and every Indian state.
          </p>

          <div className="mt-8 flex flex-wrap gap-3">
            <a
              href="#knowledge"
              className="group inline-flex items-center gap-2 px-6 py-3 bg-[#8B0F1A] hover:bg-[#6d0b14] text-white text-sm font-semibold rounded-full transition-all"
            >
              Explore Knowledge Centre
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </a>
            <a
              href="#membership"
              className="inline-flex items-center gap-2 px-6 py-3 border border-[#8B0F1A] text-[#8B0F1A] hover:bg-[#8B0F1A] hover:text-white text-sm font-semibold rounded-full transition-all"
            >
              Become a Member
            </a>
          </div>

          {/* Stats Section */}
          {/* <div className="mt-10 grid grid-cols-3 gap-4 max-w-lg">
            {[
              { icon: User, n: "4.5 L+", l: "Members" },
              { icon: Globe2, n: "60+", l: "Sectors" },
              { icon: Newspaper, n: "1,200+", l: "Reports" },
            ].map((s) => (
              <div key={s.l} className="flex items-start gap-2">
                <s.icon className="h-5 w-5 text-[#E8A83A] mt-1" />
                <div>
                  <div className="text-2xl font-bold text-neutral-900">{s.n}</div>
                  <div className="text-xs text-neutral-500 uppercase">{s.l}</div>
                </div>
              </div>
            ))}
          </div> */}
        </div>

        {/* Right Column — Carousel (Fixed Vertical Infinite Loop) */}
        <div className="lg:col-span-5">
          <div
            className="relative"
            onMouseEnter={() => setIsPaused(true)}
            onMouseLeave={() => setIsPaused(false)}
          >
            {/* Glow Effect */}
            <div className="absolute -inset-3 bg-gradient-to-br from-[#E8A83A]/40 to-[#8B0F1A]/20 blur-2xl rounded-[2rem]" />

            {/* Container */}
            {/* <div className="relative rounded-[2rem] overflow-hidden border border-white shadow-2xl h-[420px] bg-black"> */}
            <div className="relative rounded-[2rem] overflow-hidden border border-white shadow-2xl h-[480px] md:h-[520px] lg:h-[560px] bg-black">
              <div
                className="flex flex-col h-full"
                onTransitionEnd={handleTransitionEnd}
                style={{
                  transform: `translateY(-${currentIndex * 100}%)`,
                  transition: isTransitioning
                    ? "transform 1000ms cubic-bezier(0.4, 0, 0.2, 1)"
                    : "none",
                }}
              >
                {cards.map((card, i) => (
                  <div key={i} className="relative h-[480px] md:h-[520px] lg:h-[560px] w-full shrink-0">
                  {/* <div key={i} className="relative h-[420px] w-full shrink-0"> */}
                    <img
                      src={card.img}
                      alt={card.title}
                      className="w-full h-full object-cover"
                      loading="eager"
                    />
                    {/* Overlay Gradient */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

                    {/* Content */}
                    <div className="absolute bottom-8 left-8 right-8 text-white">
                      {/* <div className="text-[10px] tracking-[0.25em] text-[#F4C95D] font-bold">
                        FLAGSHIP EVENT
                      </div> */}
                     <div className="mt-2 font-serif text-2xl md:text-3xl leading-tight inline-block bg-black/50 px-2 py-1 rounded">
                        {card.title}
                      </div>
                      {/* <div className="text-sm text-white/80 mt-2">
                        {card.date}
                      </div> */}
                    </div>

                    {/* <div className="absolute top-6 right-6 px-4 py-1.5 rounded-full bg-white/95 text-[#8B0F1A] text-[11px] font-bold shadow-lg backdrop-blur">
                      REGISTRATIONS OPEN
                    </div> */}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Ticker Section */}
      {/* <div className="relative border-y border-[#8B0F1A]/15 bg-white/70 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-6 flex items-center h-12 gap-4">
          <div className="shrink-0 flex items-center gap-2 pr-4 border-r border-neutral-200">
            <span className="inline-flex h-2 w-2 rounded-full bg-[#8B0F1A] animate-ping" />
            <span className="text-[11px] font-bold tracking-[0.2em] text-[#8B0F1A]">
              LIVE UPDATES
            </span>
          </div>

          <div className="overflow-hidden relative flex-1">
            <div className="flex gap-10 animate-[marquee_50s_linear_infinite] hover:[animation-play-state:paused] whitespace-nowrap">
              {loop.map((t, i) => (
                <a
                  key={i}
                  href="#knowledge"
                  className="text-[13px] text-neutral-700 hover:text-[#8B0F1A] font-medium inline-flex items-center gap-2"
                >
                  <span className="text-[#E8A83A]">◆</span>
                  {t}
                </a>
              ))}
            </div>
          </div>
        </div>
      </div> */}
    </section>
  );
}